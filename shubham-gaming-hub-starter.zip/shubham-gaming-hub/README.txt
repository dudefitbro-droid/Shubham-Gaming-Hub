SHUBHAM GAMING HUB — starter website

WHAT'S INCLUDED
- index.html: single-file responsive gaming hub
- Nitro Rush 3D is preloaded as the first game
- Search, add, edit and delete game cards
- Optional thumbnail URL, description and genre

HOW TO PREVIEW
1. Extract the ZIP.
2. Open index.html in Chrome.

IMPORTANT DATA NOTE
This first version saves game additions in the browser's localStorage. That means additions made on one device/browser are not automatically visible to every visitor. The "Manage Games" panel is a prototype, not secure admin authentication.
For a real shared admin panel (add once, visible to everyone), the next step is connecting a database such as Supabase and adding admin login.

HOW TO DEPLOY
1. Create a GitHub repository named shubham-gaming-hub.
2. Upload index.html to the repository root.
3. In Vercel, import that repository and deploy.
4. Add your custom domain later if desired.

HOW TO ADD A GAME IN THIS PROTOTYPE
Click "Manage Games" or "Add a Game", enter the game name and full https:// link, then Save Game.
